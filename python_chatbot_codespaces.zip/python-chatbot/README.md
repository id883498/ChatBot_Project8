# Python Console Chatbot (GitHub Codespaces Ready)

This is a simple console-based chatbot app ready for GitHub Codespaces.

## Run Locally

```bash
python main.py
```

## Codespaces Setup

1. Open this repo in GitHub
2. Click the `Code` button → `Codespaces` → `Create codespace on main`
3. Terminal will open, and run:

```bash
python main.py
```

Enjoy chatting in your browser!
